const Store = require("../models/Store");

const { normalizeProduct, roundCurrency } = require("../lib/analytics");
const { isMongoReady } = require("../lib/db");
const { createHttpError } = require("../lib/errors");
const { escapeRegex, normalizeText } = require("../lib/validators");
const { createId, readLocalStore, writeLocalStore } = require("./fileStore");

function sortProducts(products) {
  return [...products].sort(
    (left, right) => new Date(right.updatedAt || 0) - new Date(left.updatedAt || 0)
  );
}

function findProductByNormalizedName(collection, normalizedName) {
  return collection.find(
    (item) =>
      normalizeText(item.normalizedName || item.name).toLowerCase() ===
      normalizedName
  );
}

async function listProducts(options = {}) {
  const search = normalizeText(options.search).toLowerCase();

  if (isMongoReady()) {
    const query = search
      ? {
          name: {
            $regex: escapeRegex(search),
            $options: "i"
          }
        }
      : {};
    const products = await Store.find(query).sort({ updatedAt: -1 }).lean();

    return products.map(normalizeProduct);
  }

  const data = await readLocalStore();
  const products = sortProducts(data.products.map(normalizeProduct));

  if (!search) {
    return products;
  }

  return products.filter((product) =>
    product.name.toLowerCase().includes(search)
  );
}

async function listAvailableProducts() {
  const products = await listProducts();
  return products.filter((product) => product.quantity > 0);
}

async function getProductById(id) {
  if (isMongoReady()) {
    const product = await Store.findById(id).lean();

    if (!product) {
      throw createHttpError(404, "Product not found.");
    }

    return normalizeProduct(product);
  }

  const data = await readLocalStore();
  const product = data.products.find((item) => String(item.id) === String(id));

  if (!product) {
    throw createHttpError(404, "Product not found.");
  }

  return normalizeProduct(product);
}

async function createProduct(payload) {
  const normalizedName = payload.name.toLowerCase();

  if (isMongoReady()) {
    const existing = await Store.findOne({ normalizedName });

    if (existing) {
      existing.name = payload.name;
      existing.quantity += payload.quantity;
      existing.price = payload.price;
      existing.category = payload.category;
      existing.sku = payload.sku;
      existing.reorderLevel = payload.reorderLevel;
      await existing.save();

      return {
        action: "restocked",
        product: normalizeProduct(existing.toObject())
      };
    }

    const product = await Store.create({
      ...payload,
      normalizedName
    });

    return {
      action: "created",
      product: normalizeProduct(product.toObject())
    };
  }

  const data = await readLocalStore();
  const existing = findProductByNormalizedName(data.products, normalizedName);

  if (existing) {
    existing.name = payload.name;
    existing.quantity = Number(existing.quantity || 0) + payload.quantity;
    existing.price = payload.price;
    existing.normalizedName = normalizedName;
    existing.category = payload.category;
    existing.sku = payload.sku;
    existing.reorderLevel = payload.reorderLevel;
    existing.totalPrice = roundCurrency(existing.quantity * existing.price);
    existing.updatedAt = new Date().toISOString();

    await writeLocalStore(data);

    return {
      action: "restocked",
      product: normalizeProduct(existing)
    };
  }

  const timestamp = new Date().toISOString();
  const product = {
    id: createId("product"),
    name: payload.name,
    normalizedName,
    category: payload.category,
    sku: payload.sku,
    reorderLevel: payload.reorderLevel,
    quantity: payload.quantity,
    price: payload.price,
    totalPrice: roundCurrency(payload.quantity * payload.price),
    createdAt: timestamp,
    updatedAt: timestamp
  };

  data.products.unshift(product);
  await writeLocalStore(data);

  return {
    action: "created",
    product: normalizeProduct(product)
  };
}

async function updateProduct(id, payload) {
  const nextNormalizedName = payload.name.toLowerCase();

  if (isMongoReady()) {
    const product = await Store.findById(id);

    if (!product) {
      throw createHttpError(404, "Product not found.");
    }

    const duplicate = await Store.findOne({
      normalizedName: nextNormalizedName,
      _id: { $ne: id }
    });

    if (duplicate) {
      throw createHttpError(409, "Another product already uses that name.");
    }

    product.name = payload.name;
    product.normalizedName = nextNormalizedName;
    product.category = payload.category;
    product.sku = payload.sku;
    product.reorderLevel = payload.reorderLevel;
    product.quantity = payload.quantity;
    product.price = payload.price;
    await product.save();

    return normalizeProduct(product.toObject());
  }

  const data = await readLocalStore();
  const product = data.products.find((item) => String(item.id) === String(id));

  if (!product) {
    throw createHttpError(404, "Product not found.");
  }

  const duplicate = data.products.find(
    (item) =>
      String(item.id) !== String(id) &&
      normalizeText(item.normalizedName || item.name).toLowerCase() ===
        nextNormalizedName
  );

  if (duplicate) {
    throw createHttpError(409, "Another product already uses that name.");
  }

  product.name = payload.name;
  product.normalizedName = nextNormalizedName;
  product.category = payload.category;
  product.sku = payload.sku;
  product.reorderLevel = payload.reorderLevel;
  product.quantity = payload.quantity;
  product.price = payload.price;
  product.totalPrice = roundCurrency(payload.quantity * payload.price);
  product.updatedAt = new Date().toISOString();

  await writeLocalStore(data);

  return normalizeProduct(product);
}

async function deleteProduct(id) {
  if (isMongoReady()) {
    const product = await Store.findByIdAndDelete(id).lean();

    if (!product) {
      throw createHttpError(404, "Product not found.");
    }

    return normalizeProduct(product);
  }

  const data = await readLocalStore();
  const index = data.products.findIndex((item) => String(item.id) === String(id));

  if (index === -1) {
    throw createHttpError(404, "Product not found.");
  }

  const [product] = data.products.splice(index, 1);
  await writeLocalStore(data);

  return normalizeProduct(product);
}

module.exports = {
  createProduct,
  deleteProduct,
  getProductById,
  listAvailableProducts,
  listProducts,
  updateProduct
};
