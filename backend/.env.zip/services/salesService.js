const Sale = require("../models/Sale");
const Store = require("../models/Store");

const { normalizeProduct, normalizeSale, roundCurrency } = require("../lib/analytics");
const { isMongoReady } = require("../lib/db");
const { createHttpError } = require("../lib/errors");
const { escapeRegex, normalizeText } = require("../lib/validators");
const { createId, readLocalStore, writeLocalStore } = require("./fileStore");

function sortSales(sales) {
  return [...sales].sort(
    (left, right) => new Date(right.date || 0) - new Date(left.date || 0)
  );
}

function matchSearch(sale, search) {
  if (!search) return true;

  const haystack = [sale.customerName, sale.productName, sale.mobile]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();

  return haystack.includes(search);
}

async function listSales(options = {}) {
  const search = normalizeText(options.search).toLowerCase();

  if (isMongoReady()) {
    const query = search
      ? {
          $or: [
            { customerName: { $regex: escapeRegex(search), $options: "i" } },
            { productName: { $regex: escapeRegex(search), $options: "i" } },
            { mobile: { $regex: escapeRegex(search), $options: "i" } }
          ]
        }
      : {};
    const sales = await Sale.find(query).sort({ date: -1, createdAt: -1 }).lean();

    return sales.map(normalizeSale);
  }

  const data = await readLocalStore();
  return sortSales(data.sales.map(normalizeSale)).filter((sale) =>
    matchSearch(sale, search)
  );
}

async function createSale(payload) {
  if (isMongoReady()) {
    const product = payload.productId
      ? await Store.findById(payload.productId)
      : await Store.findOne({
          normalizedName: normalizeText(payload.productName).toLowerCase()
        });

    if (!product) {
      throw createHttpError(404, "Product not found.");
    }

    if (product.quantity < payload.quantity) {
      throw createHttpError(400, `Only ${product.quantity} units are available.`);
    }

    const previousQuantity = product.quantity;
    const unitPrice = Number(product.price) || 0;
    product.quantity -= payload.quantity;
    product.totalPrice = roundCurrency(product.quantity * unitPrice);
    await product.save();

    try {
      const sale = await Sale.create({
        customerName: payload.customerName,
        mobile: payload.mobile,
        productId: String(product._id),
        productName: product.name,
        quantity: payload.quantity,
        unitPrice,
        totalPrice: roundCurrency(payload.quantity * unitPrice),
        date: new Date()
      });

      return {
        sale: normalizeSale(sale.toObject()),
        product: normalizeProduct(product.toObject())
      };
    } catch (error) {
      product.quantity = previousQuantity;
      product.totalPrice = roundCurrency(previousQuantity * unitPrice);
      await product.save().catch(() => null);
      throw error;
    }
  }

  const data = await readLocalStore();
  const normalizedProductName = normalizeText(payload.productName).toLowerCase();
  const product = data.products.find((item) => {
    if (payload.productId) {
      return String(item.id) === String(payload.productId);
    }

    return (
      normalizeText(item.normalizedName || item.name).toLowerCase() ===
      normalizedProductName
    );
  });

  if (!product) {
    throw createHttpError(404, "Product not found.");
  }

  if (Number(product.quantity) < payload.quantity) {
    throw createHttpError(400, `Only ${product.quantity} units are available.`);
  }

  const timestamp = new Date().toISOString();
  const unitPrice = Number(product.price) || 0;
  product.quantity -= payload.quantity;
  product.totalPrice = roundCurrency(product.quantity * unitPrice);
  product.updatedAt = timestamp;

  const sale = {
    id: createId("sale"),
    customerName: payload.customerName,
    mobile: payload.mobile,
    productId: String(product.id),
    productName: product.name,
    quantity: payload.quantity,
    unitPrice,
    totalPrice: roundCurrency(payload.quantity * unitPrice),
    date: timestamp,
    createdAt: timestamp,
    updatedAt: timestamp
  };

  data.sales.unshift(sale);
  await writeLocalStore(data);

  return {
    sale: normalizeSale(sale),
    product: normalizeProduct(product)
  };
}

module.exports = {
  createSale,
  listSales
};
