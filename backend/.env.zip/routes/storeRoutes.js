const express = require("express");
const asyncHandler = require("../lib/asyncHandler");
const { validateProductPayload } = require("../lib/validators");
const {
  createProduct,
  deleteProduct,
  getProductById,
  listAvailableProducts,
  listProducts,
  updateProduct
} = require("../services/storeService");

const router = express.Router();





const createProductHandler = asyncHandler(async (req, res) => {
  const payload = validateProductPayload(req.body);
  const result = await createProduct(payload);

  res.status(result.action === "created" ? 201 : 200).json(result);
});
// 🔥 Get only product names (for dropdown)
router.get(
  "/names",
  asyncHandler(async (req, res) => {
    const products = await listAvailableProducts();
    res.json(products);
  })
);

router.get(
  "/",
  asyncHandler(async (req, res) => {
    const products = await listProducts({ search: req.query.search });
    res.json(products);
  })
);

router.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const product = await getProductById(req.params.id);
    res.json(product);
  })
);

router.post("/", createProductHandler);
router.post("/add", createProductHandler);

router.put(
  "/:id",
  asyncHandler(async (req, res) => {
    const payload = validateProductPayload(req.body);
    const product = await updateProduct(req.params.id, payload);

    res.json({ product });
  })
);

router.delete(
  "/:id",
  asyncHandler(async (req, res) => {
    const product = await deleteProduct(req.params.id);
    res.json({ product });
  })
);

module.exports = router;
