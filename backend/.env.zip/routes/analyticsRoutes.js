const express = require("express");

const asyncHandler = require("../lib/asyncHandler");
const { buildRetailIntelligenceSummary } = require("../lib/retailIntelligence");
const { getStorageMode } = require("../lib/db");
const { listSales } = require("../services/salesService");
const { listProducts } = require("../services/storeService");

const router = express.Router();

async function getSummary() {
  const [products, sales] = await Promise.all([listProducts(), listSales()]);
  return buildRetailIntelligenceSummary(products, sales);
}

router.get(
  "/overview",
  asyncHandler(async (req, res) => {
    res.json({
      ...(await getSummary()),
      storageMode: getStorageMode()
    });
  })
);

router.get(
  "/forecast",
  asyncHandler(async (req, res) => {
    const summary = await getSummary();

    res.json({
      ...summary.forecast,
      storageMode: getStorageMode()
    });
  })
);

router.get(
  "/recommendations",
  asyncHandler(async (req, res) => {
    const summary = await getSummary();

    res.json({
      ...summary.productRecommendations,
      storageMode: getStorageMode()
    });
  })
);

router.get(
  "/customers",
  asyncHandler(async (req, res) => {
    const summary = await getSummary();

    res.json({
      ...summary.customerInsights,
      storageMode: getStorageMode()
    });
  })
);

router.get(
  "/customer-service",
  asyncHandler(async (req, res) => {
    const summary = await getSummary();

    res.json({
      ...summary.customerService,
      storageMode: getStorageMode()
    });
  })
);

module.exports = router;
