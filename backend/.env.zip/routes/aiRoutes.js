module.exports = require("./assistantRoutes");
